/*
 * Created by: Erich Eichinger
 * Created: Montag, 16. April 2007
 */

using System;
using System.IO;
using System.Text;
using NUnit.Framework;

namespace HttpRequestRecorder
{
    [TestFixture]
    public class PlayerTests
    {
        [Test]
        [Explicit]
        public void ReplayEvents()
        {
            string testevents =
                @"
                    <request id=""1"" session=""zkzohybn0xzsdsaztzy0tv55"" method=""GET"" url=""/Default.aspx"">
						<headers>
							<header name=""Connection"" value=""keep-alive"" />
							<header name=""Keep-Alive"" value=""300"" /><header name=""Accept"" value=""text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5"" /><header name=""Accept-Charset"" value=""ISO-8859-1,utf-8;q=0.7,*;q=0.7"" /><header name=""Accept-Encoding"" value=""gzip,deflate"" /><header name=""Accept-Language"" value=""en,de-de;q=0.8,en-us;q=0.5,de;q=0.3"" /><header name=""Cookie"" value="".ASPXAUTH=48D4AAC210920393A329F9113C284F5A2400C9C3A367B70CAF6B83F0C49188AFE65782A522537D9842A6C4F749AC2BBB71C6A6CFFE8523D31FE84F1099A9E842FACA9FAAAD5C41A60C276DE1A822E215E1247F1E9B0AB8F230962FB9621BAC0E4A2E0344870F7EEF99573FC9B8258BBAC5DC1BC02384D028890FC8AFAD74DB41; ASP.NET_SessionId=zkzohybn0xzsdsaztzy0tv55"" /><header name=""Host"" value=""localhost:81"" /><header name=""Referer"" value=""http://localhost:81/Default.aspx"" /><header name=""User-Agent"" value=""Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.8.1.3) Gecko/20070309 Firefox/2.0.0.3"" /></headers>
					</request>
                    <request id=""2"" session=""zkzohybn0xzsdsaztzy0tv55"" method=""GET"" url=""/Default.aspx""><headers><header name=""Cache-Control"" value=""max-age=0"" /><header name=""Connection"" value=""keep-alive"" /><header name=""Keep-Alive"" value=""300"" /><header name=""Accept"" value=""text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5"" /><header name=""Accept-Charset"" value=""ISO-8859-1,utf-8;q=0.7,*;q=0.7"" /><header name=""Accept-Encoding"" value=""gzip,deflate"" /><header name=""Accept-Language"" value=""en,de-de;q=0.8,en-us;q=0.5,de;q=0.3"" /><header name=""Cookie"" value="".ASPXAUTH=48D4AAC210920393A329F9113C284F5A2400C9C3A367B70CAF6B83F0C49188AFE65782A522537D9842A6C4F749AC2BBB71C6A6CFFE8523D31FE84F1099A9E842FACA9FAAAD5C41A60C276DE1A822E215E1247F1E9B0AB8F230962FB9621BAC0E4A2E0344870F7EEF99573FC9B8258BBAC5DC1BC02384D028890FC8AFAD74DB41; ASP.NET_SessionId=zkzohybn0xzsdsaztzy0tv55"" /><header name=""Host"" value=""localhost:81"" /><header name=""Referer"" value=""http://localhost:81/Default.aspx"" /><header name=""User-Agent"" value=""Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.8.1.3) Gecko/20070309 Firefox/2.0.0.3"" /></headers></request>
                    <request id=""3"" session=""zkzohybn0xzsdsaztzy0tv55"" method=""GET"" url=""/Default.aspx""><headers><header name=""Cache-Control"" value=""max-age=0"" /><header name=""Connection"" value=""keep-alive"" /><header name=""Keep-Alive"" value=""300"" /><header name=""Accept"" value=""text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5"" /><header name=""Accept-Charset"" value=""ISO-8859-1,utf-8;q=0.7,*;q=0.7"" /><header name=""Accept-Encoding"" value=""gzip,deflate"" /><header name=""Accept-Language"" value=""en,de-de;q=0.8,en-us;q=0.5,de;q=0.3"" /><header name=""Cookie"" value="".ASPXAUTH=48D4AAC210920393A329F9113C284F5A2400C9C3A367B70CAF6B83F0C49188AFE65782A522537D9842A6C4F749AC2BBB71C6A6CFFE8523D31FE84F1099A9E842FACA9FAAAD5C41A60C276DE1A822E215E1247F1E9B0AB8F230962FB9621BAC0E4A2E0344870F7EEF99573FC9B8258BBAC5DC1BC02384D028890FC8AFAD74DB41; ASP.NET_SessionId=zkzohybn0xzsdsaztzy0tv55"" /><header name=""Host"" value=""localhost:81"" /><header name=""Referer"" value=""http://localhost:81/Default.aspx"" /><header name=""User-Agent"" value=""Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.8.1.3) Gecko/20070309 Firefox/2.0.0.3"" /></headers></request>
                    <request id=""4"" session=""zkzohybn0xzsdsaztzy0tv55"" method=""POST"" url=""/Default.aspx""><headers><header name=""Cache-Control"" value=""max-age=0"" /><header name=""Connection"" value=""keep-alive"" /><header name=""Keep-Alive"" value=""300"" /><header name=""Accept"" value=""text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5"" /><header name=""Accept-Charset"" value=""ISO-8859-1,utf-8;q=0.7,*;q=0.7"" /><header name=""Accept-Encoding"" value=""gzip,deflate"" /><header name=""Accept-Language"" value=""en,de-de;q=0.8,en-us;q=0.5,de;q=0.3"" /><header name=""Cookie"" value="".ASPXAUTH=48D4AAC210920393A329F9113C284F5A2400C9C3A367B70CAF6B83F0C49188AFE65782A522537D9842A6C4F749AC2BBB71C6A6CFFE8523D31FE84F1099A9E842FACA9FAAAD5C41A60C276DE1A822E215E1247F1E9B0AB8F230962FB9621BAC0E4A2E0344870F7EEF99573FC9B8258BBAC5DC1BC02384D028890FC8AFAD74DB41; ASP.NET_SessionId=zkzohybn0xzsdsaztzy0tv55"" /><header name=""Host"" value=""localhost:81"" /><header name=""Referer"" value=""http://localhost:81/Default.aspx"" /><header name=""User-Agent"" value=""Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.8.1.3) Gecko/20070309 Firefox/2.0.0.3"" /></headers></request>
                  ";
            Player p = new Player(new Uri("http://localhost:81"));
            p.Play( new MemoryStream( Encoding.UTF8.GetBytes(testevents) ), new int[]{ 500 } );
        }
    }
}