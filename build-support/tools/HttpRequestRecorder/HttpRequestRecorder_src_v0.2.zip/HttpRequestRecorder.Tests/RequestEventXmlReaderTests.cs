using System;
using System.Collections;
using System.IO;
using System.Text;
using NUnit.Framework;

namespace HttpRequestRecorder
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	[TestFixture]
	public class RequestEventXmlReaderTests
	{		
		[Test]
		public void ReadDefault()
		{
			string testpayload = Convert.ToBase64String(Encoding.UTF8.GetBytes("testpayload"));
			string testdata = @"
				<!-- some comment -->
				<request id='0' session='session' method='GET' url='/theurl.ext'><headers><header name='h1' value='v1'/><header name='h2' value='v2'></header></headers><payload>" + testpayload + @"</payload></request>
				<!-- some comment -->
				<request id='1' session='session' method='GET' url='/theurl.ext'><!-- some comment --><headers><header name='h1' value='v1'/><header name='h2' value='v2'></header></headers><payload>" + testpayload + @"</payload></request>
				
				<!-- some comment -->
				
				<request id='2' session='session' method='GET' url='/theurl.ext'>
				   <!-- contains whitespaces -->   <headers>
                      <header name='h1' value='v1'/>   
   <header name='h2' value='v2'>
                   </header>
      </headers>
          <payload>" + testpayload + @"</payload>
      </request>
"
				+"";
			RequestEventXmlReader r = new RequestEventXmlReader( new MemoryStream( Encoding.UTF8.GetBytes(testdata)) );
			int count = 0;
			foreach(RequestEvent requestEvent in r)
			{
				Assert.AreEqual(count, requestEvent.EventId);
				Assert.AreEqual("session", requestEvent.SessionId);
				Assert.AreEqual("GET", requestEvent.Method);
				Assert.AreEqual("/theurl.ext", requestEvent.RawUrl);
				Assert.IsNotNull(requestEvent.Headers);
				Assert.AreEqual(2, requestEvent.Headers.Count);
				Assert.AreEqual(testpayload, requestEvent.Base64EncodedPayload);
				count++;
			}
		}

		[Test]
		public void RequestElementMayBeEmpty()
		{
			string testdata = @""
				+"<request id='0' session='session' method='GET' url='/theurl.ext' />"
				+"<request id='1' session='session' method='GET' url='/theurl.ext'></request>"
				+"";

			RequestEventXmlReader r = new RequestEventXmlReader( new MemoryStream( Encoding.UTF8.GetBytes(testdata)) );
			foreach(RequestEvent requestEvent in r)
			{
				Assert.IsNotNull(requestEvent.Headers);
				Assert.IsNull(requestEvent.Base64EncodedPayload);
			}
		}
		
		[Test]
		public void PayloadIsNullIfPayloadElementHasNoLength()
		{
			string testdata = @""
				+"<request id='0' session='session' method='GET' url='/theurl.ext'><headers /></request>"
				+"<request id='1' session='session' method='GET' url='/theurl.ext'><headers></headers><payload /></request>"
				+"<request id='2' session='session' method='GET' url='/theurl.ext'><headers></headers><payload></payload></request>"
				+"<request id='3' session='session' method='GET' url='/theurl.ext'><headers /></request>"
				+"";

			RequestEventXmlReader r = new RequestEventXmlReader( new MemoryStream( Encoding.UTF8.GetBytes(testdata)) );
			foreach(RequestEvent requestEvent in r)
			{
				Assert.IsNull(requestEvent.Base64EncodedPayload);
			}
		}
	}
}
