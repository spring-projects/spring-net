using System;
using System.Collections;
using System.IO;
using System.Net;

namespace HttpRequestRecorder
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class PlayerConsole
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static int Main(string[] args)
		{
            if (args.Length < 2)
            {
                ShowUsage();
				return 0;
            }

            Player player = new Player( new Uri("http://" + args[0]) );
            FileInfo xmlEvents = new FileInfo(args[1]);
            if (!xmlEvents.Exists)
            {
                Console.WriteLine(string.Format("Inputfile {0} does not exist", xmlEvents.FullName));
                return 1;
            }

			int repeat = 1;
			if (args.Length > 2)
			{
				repeat = Int32.Parse(args[2]);
			}

			int[] haltOnStatusCodes = new int[] {};
			if (args.Length > 3)
			{
				string[] strStatusCodes = args[3].Split(',',';');
				haltOnStatusCodes = new int[strStatusCodes.Length];
				for(int i=0;i<haltOnStatusCodes.Length;i++)
				{
					string str = strStatusCodes[i].Trim();
					if (!Enum.IsDefined(typeof(HttpStatusCode), Int32.Parse(str)))
					{
						throw new ArgumentOutOfRangeException(string.Format("unknown HTTP Statuscode '{0}' at position {1}", str, i));
					}
					haltOnStatusCodes[i] = (int) Enum.Parse(typeof(HttpStatusCode), str, true);
				}
			}

            try
            {
				int cntRequests = 0;
				DateTime dtStart = DateTime.Now;

            	for (int runs = 0;runs<repeat;runs++)
            	{
            		cntRequests += player.Play( xmlEvents.OpenRead(), haltOnStatusCodes );
            	}

				double seconds = DateTime.Now.Subtract(dtStart).TotalSeconds;
				Console.WriteLine("Duration: {0:F2}s, Total Requests:{1} ({2:F2} Req/s)", seconds, cntRequests, cntRequests/seconds );
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return 2;
            }

            return 0;
		}

	    private static void ShowUsage()
	    {
	        Console.WriteLine("Usage:");
            Console.WriteLine("  PlayerConsole host[:port] <path to events.xml> [number of repeats] [comma separated HTTP statuscodes to halt on]");
            Console.WriteLine();
	    }
	}
}
