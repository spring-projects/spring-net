
using System;
using System.Collections;
using System.IO;
using System.Xml;

namespace HttpRequestRecorder
{
	public class RequestEventXmlReader : IEnumerable, IDisposable
	{
		private Stream _inputStream;
		
		public RequestEventXmlReader( Stream inputStream )
		{			
			_inputStream = inputStream;
		}

		public IRequestEventEnumerator GetEnumerator()
		{
			XmlTextReader xmlTextReader = new XmlTextReader(this._inputStream, XmlNodeType.Element, (XmlParserContext)null);
			xmlTextReader.WhitespaceHandling = WhitespaceHandling.None;
			return new RequestEventXmlReaderEnumerator(xmlTextReader);
		}
		
		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}

		public void Dispose()
		{
			_inputStream.Close();
		}
	}
}