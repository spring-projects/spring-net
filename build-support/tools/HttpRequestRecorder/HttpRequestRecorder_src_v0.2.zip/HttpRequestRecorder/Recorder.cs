using System;
using System.Collections;
using System.Collections.Specialized;
using System.IO;
using System.Web;

namespace HttpRequestRecorder
{
	public class Recorder
	{
		private static readonly object SyncRoot = new object();	
		private static Guid ApplicationInstanceId = Guid.NewGuid();
		
		private static int s_eventCount = 0;
		private static ArrayList s_bufferedEvents = new ArrayList();

		private static RecorderSettings s_settings;
		
		public static void EnsureRecorderInitialized(HttpApplication application)
		{
			if (s_settings == null)
			{
				lock(SyncRoot)
				{
					if (s_settings == null)
					{
						NameValueCollection settings = (NameValueCollection) application.Context.GetConfig("httpRequestRecorder");
					
						int bufferSize = Int32.Parse(settings["BufferSize"]);
						if (bufferSize < 1) throw new ArgumentOutOfRangeException("bufferSize must be greater than 0", bufferSize, "bufferSize");

						string outputPath = application.Context.Request.MapPath(settings["OutputPath"]);
						if (!Directory.Exists(outputPath)) throw new ArgumentException(string.Format("OutputPath '{0}' does not exist", outputPath), "OutputPath");
						outputPath = Path.Combine(outputPath, "record_" + ApplicationInstanceId + ".xml");						
						FileInfo f = new FileInfo(outputPath);
						f.Create().Close();                        
						f.Delete();

						s_settings = new RecorderSettings(bufferSize, outputPath);
						
						AppDomain.CurrentDomain.DomainUnload += new EventHandler(CurrentDomain_DomainUnload);
					}
				}
			}
		}
		
		public static void RecordRequestEvent(string sessionId, HttpRequest request)
		{
			lock(SyncRoot)
			{
				s_eventCount++;
				RequestEvent requestEvent = new RequestEvent(s_eventCount, sessionId, request);
				s_bufferedEvents.Add(requestEvent);
				
				if (s_bufferedEvents.Count > s_settings.BufferSize)
				{
					FlushEventBuffer(s_settings.OutputPath, s_bufferedEvents);
				}
			}
		}
		
		private static void FlushEventBuffer(string outputPath, ArrayList events)
		{
            int cntEvents = events.Count;

            if (cntEvents == 0) return;
            
			using(RequestEventXmlWriter writer = new RequestEventXmlWriter(outputPath))
			{
				for(int i=0;i<cntEvents;i++)
				{
					RequestEvent requestEvent = (RequestEvent) events[i];
					writer.WriteEvent(requestEvent);
				}
				events.Clear();
			}
		}

		private static void CurrentDomain_DomainUnload(object sender, EventArgs e)
		{
			Flush();
		}

		public static void Flush()
		{
			lock(SyncRoot)
			{
				FlushEventBuffer(s_settings.OutputPath, s_bufferedEvents);
			}
		}
	}
}