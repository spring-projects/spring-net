/*
 * Created by: 
 * Created: Montag, 16. April 2007
 */

using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace HttpRequestRecorder
{
	[Serializable]
	public class PlayRequestException : ApplicationException
	{
		private RequestEvent _request;
		private Response _response;

		public PlayRequestException(string message, RequestEvent request, Response response) : base(message)
		{
			_request = request;
			_response = response;
		}

		public PlayRequestException(SerializationInfo info, StreamingContext context) : base(info, context)
		{
		}

		public override string Message
		{
			get
			{
				return base.Message + string.Format(" - Executing Request[EventId='{0}'] Url '{1}' resulted in Response Status '{2} {3}'", _request.EventId, _request.RawUrl, _response.StatusCode, _response.StatusMessage );
			}
		}

	}

	[Serializable]
	public class Response
	{
		private static readonly Regex s_ProtocolHeader = new Regex(@"(?'protocol'[A-Z]+)/(?'version'1\.[0-1])\s(?'statuscode'[0-9]{3})\s(?'statusmessage'.+)", RegexOptions.Compiled|RegexOptions.CultureInvariant|RegexOptions.ECMAScript);
		private int _statusCode;
		private string _statusMessage;
		private byte[] _payLoad;

		public Response( Stream stream )
		{
			_payLoad = ReadResponse(stream);
			string firstLine = ReadLine(_payLoad, 0);
			Match m = s_ProtocolHeader.Match(firstLine);
			_statusCode = Int32.Parse(m.Groups["statuscode"].Value);
			_statusMessage = (string)m.Groups["statusmessage"].Value;
		}

		public int StatusCode
		{
			get { return this._statusCode; }
		}

		public string StatusMessage
		{
			get { return this._statusMessage; }
		}

		public byte[] PayLoad
		{
			get { return this._payLoad; }
		}

		/// <summary>
		/// Read in a line from the byte array starting scanning for CR/LF at offset
		/// </summary>
		private static string ReadLine(byte[] data, int offset)
		{
			int i = offset;
			for(i=offset;i<data.Length;i++)
			{
				if (data[i] == 10)
				{
					break;
				}
			}
			return Encoding.Default.GetString(data, offset, i - offset);
		}

		private static byte[] ReadResponse(Stream stream)
		{
			Byte[] buffer = null;
			// Receive the server home page content.
			int bytes = 0;

			ArrayList buffers = new ArrayList();

			// The following will block until te page is transmitted.
			int totalByteCount = 0;
			do
			{
				buffer = new byte[4096];
				bytes = stream.Read(buffer, 0, buffer.Length);
				totalByteCount += bytes;
				buffers.Add(buffer);
			} while (bytes > 0);

			int bytesCopied = 0;
			byte[] totalBytes = new byte[totalByteCount];
			for(int i=0;i<buffers.Count;i++)
			{
				byte[] currentData = (byte[])buffers[i];
				int bytesToCopy = Math.Min(currentData.Length, totalBytes.Length - bytesCopied);
				Array.Copy( currentData, 0, totalBytes, bytesCopied, bytesToCopy );
//				currentData.CopyTo( totalBytes, bytesCopied );
				bytesCopied += bytesToCopy;
			}

			return totalBytes;
		}
	}

    public class Player
    {
        private Uri _baseUri;

        public Player(Uri baseUri)
        {
            this._baseUri = baseUri;
        }

        public int Play(Stream inputStream, int[] haltOnStatusCodes)
        {
			int cntRequests = 0;
            RequestEventXmlReader reader = new RequestEventXmlReader(inputStream);
            using (reader)
            {
				Response result = null;

                foreach (RequestEvent requestEvent in reader)
                {
                    result = SubmitRequest(this._baseUri, requestEvent);
					cntRequests++;

					if (-1 < Array.IndexOf(haltOnStatusCodes, result.StatusCode))
					{
						throw new PlayRequestException("Abort run because of 'HaltOnStatusCode' rule", requestEvent, result);
					}
				}
			}

			return cntRequests;
        }

		/// <summary>
		/// Submits a <see cref="RequestEvent"/> and returns the result as string.
		/// </summary>
        public static Response SubmitRequest(Uri baseUri, RequestEvent requestEvent)
        {
            Uri requestUri = new Uri(baseUri, requestEvent.RawUrl);
            Trace.WriteLine(string.Format("Submitting request {0} with uri {1}", requestEvent.EventId, requestUri));

            requestEvent.Headers["Connection"] = "Close";
            requestEvent.Headers["Host"] = baseUri.Host + ((baseUri.Port != 80) ? ":" + baseUri.Port : "");
            requestEvent.Headers.Remove("Keep-Alive");

            NetworkStream upStream = OpenStream(baseUri);
            using (upStream)
            {
                // construct header
                StringBuilder hdr = new StringBuilder();
                hdr.Append(requestEvent.Method + " " + requestEvent.RawUrl + " HTTP/1.1\r\n");
                foreach (string key in requestEvent.Headers.AllKeys)
                {
                    if (key == null || key.Length == 0) continue;

                    string[] vals = requestEvent.Headers.GetValues(key);
                    hdr.Append(key + ": " + vals[0] + "\r\n");
                    for (int i = 1; i < vals.Length; i++)
                    {
                        hdr.Append("\t" + vals[i] + "\r\n");
                    }
                }
                hdr.Append("\r\n");

                // send header
                byte[] headerData = Encoding.Default.GetBytes(hdr.ToString());
                upStream.Write(headerData, 0, headerData.Length);

                // submit payload if any
                if (requestEvent.Base64EncodedPayload != null)
                {
                    byte[] requestData = Convert.FromBase64String(requestEvent.Base64EncodedPayload);
                    upStream.Write(requestData, 0, requestData.Length);
                }

                // wair for response
                Response response =  new Response(upStream);
                upStream.Close();

				return response;
            }
        }

        private static NetworkStream OpenStream(Uri baseUri)
        {
            IPAddress address = Dns.Resolve(baseUri.Host).AddressList[0];
            IPEndPoint endPoint = new IPEndPoint(address, baseUri.Port);
            Socket clientSocket = new Socket(endPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            clientSocket.Connect(endPoint);

            return new NetworkStream(clientSocket, true);
        }
    }
}