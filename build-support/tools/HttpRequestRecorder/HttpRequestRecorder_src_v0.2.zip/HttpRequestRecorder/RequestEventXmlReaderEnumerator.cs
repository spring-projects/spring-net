using System;
using System.Collections;
using System.Xml;

namespace HttpRequestRecorder
{
	public class RequestEventXmlReaderEnumerator : IRequestEventEnumerator
	{
		private XmlReader _reader;
		private long _lastEventId;
		private RequestEvent _current;
		
		public RequestEventXmlReaderEnumerator( XmlReader reader )
		{
			this._lastEventId = -1;
			_reader = reader;
		}

		public bool MoveNext()
		{
			try
			{
				_current = ParseNextRequestEvent(_reader);
				this._lastEventId = (_current == null) ? -1 : _current.EventId;
			}
			catch(Exception ex)
			{
				throw new XmlException(string.Format("Error parsing XML stream at element following <request id='{0}'>", this._lastEventId), ex);
			}
			return (_current != null);
		}

		private static RequestEvent ParseNextRequestEvent(XmlReader reader)
		{
			long eventId;
			string method;
			string session;
			string url;
			
			// move to next "request" element
			while(reader.Read() && (!reader.IsStartElement("request")))
			{
			}
			
			if (reader.EOF) return null;
			
			eventId = Int64.Parse(reader.GetAttribute("id"));
			method = reader.GetAttribute("method");
			session = reader.GetAttribute("session");
			url = reader.GetAttribute("url");
			
			RequestEvent requestEvent = new RequestEvent(eventId, session, method, url);
			
			if (!reader.IsEmptyElement)
			{
				reader.Read();
				
				while(reader.LocalName != "request" && reader.NodeType != XmlNodeType.EndElement)
				{
					reader.MoveToContent();
					
					switch(reader.LocalName)
					{
						case "headers":
							if (!reader.IsEmptyElement)
							{
								reader.Read();
								while (reader.IsStartElement("header"))
								{
									string key = reader.GetAttribute("name");
									string val = reader.GetAttribute("value");
									requestEvent.Headers.Add(key, val);
									if (!reader.IsEmptyElement)
									{
										// </header>
										reader.Skip();
									} 
									else
									{
										reader.Read();
									}
								}
								reader.ReadEndElement(); // </headers>
							}			
							else
							{
								reader.Read();
							}
							break;
						case "payload":
							if (!reader.IsEmptyElement)
							{
								string payload = reader.ReadElementString();
								if (payload != null && payload.Length > 0)
								{
									requestEvent.Base64EncodedPayload = payload;
								}
							}
							else
							{
								reader.Read();
							}
							break;
//						case "request":
//							return requestEvent;
						default:							
							throw new FormatException(string.Format("unknown element '{0}'", reader.LocalName));
					}					
				}				
				reader.ReadEndElement(); // close "request" element
			}
			
			return requestEvent;
		}

		public void Reset()
		{
			throw new InvalidOperationException("RequestEventXmlReaderEnumerator cannot be reset");
		}

		public RequestEvent Current
		{
			get
			{
				return _current;
			}
		}
		
		object IEnumerator.Current
		{
			get
			{
				return this.Current;
			}
		}
		
	}
}