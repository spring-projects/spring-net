using System;
using System.Collections.Specialized;
using System.IO;
using System.Web;

namespace HttpRequestRecorder
{
	/// <summary>
	/// Summary description for HttpRequestEvent.
	/// </summary>
	[Serializable]
	public class RequestEvent
	{
		private long _eventId;
		private string _method;
		private string _rawUrl;
		private string _sessionId;
		private NameValueCollection _headers;
		private string _base64EncodedPayload;
		
		public RequestEvent(long eventId, string sessionId, string method, string rawUrl)
		{
			this._eventId = eventId;
			this._sessionId = sessionId;
			this._method = method;
			this._rawUrl = rawUrl;
			this._headers = new NameValueCollection();				
		}
		
		public RequestEvent(long eventId, string sessionId, HttpRequest request)
		{
			this._eventId = eventId;
			this._method = request.HttpMethod;
			this._rawUrl = request.RawUrl;
			this._sessionId = sessionId;
			this._headers = new NameValueCollection(request.Headers);
			Stream istm = request.InputStream;
			using(istm)
			{
				long totalBytes = istm.Length;
				if(totalBytes > 0)
				{
					byte[] payload = new byte[totalBytes];
					long payloadPosition = 0;
					byte[] buffer = new byte[4096];
					while(payloadPosition < totalBytes)
					{
						int bytesRead = istm.Read(buffer, 0, buffer.Length);
						Array.Copy( buffer, 0, payload, payloadPosition, bytesRead );
						payloadPosition += bytesRead;
					}
					_base64EncodedPayload = Convert.ToBase64String(payload);
				}
			}
		}

		public long EventId
		{
			get { return this._eventId; }
		}

		public string SessionId
		{
			get { return this._sessionId; }
		}

		public string Method
		{
			get { return this._method; }
		}

		public string RawUrl
		{
			get { return this._rawUrl; }
		}

		public NameValueCollection Headers
		{
			get { return this._headers; }
		}

		public string Base64EncodedPayload
		{
			get { return this._base64EncodedPayload; }
			set { this._base64EncodedPayload = value; }
		}
	}
}