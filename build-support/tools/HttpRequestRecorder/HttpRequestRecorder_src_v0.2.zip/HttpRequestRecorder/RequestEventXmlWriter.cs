using System;
using System.Collections.Specialized;
using System.IO;
using System.Text;
using System.Xml;

namespace HttpRequestRecorder
{
	public class RequestEventXmlWriter : IDisposable
	{
		private XmlWriter _writer;


		public RequestEventXmlWriter( string outputPath )
		{
			FileStream os = new FileStream(outputPath, FileMode.Append, FileAccess.Write, FileShare.None);
			this._writer = new XmlTextWriter(os, Encoding.Default);			
		}
		
		public void WriteEvent( RequestEvent requestEvent )
		{
			this._writer.WriteStartElement("request");
			this._writer.WriteAttributeString("id", ""+requestEvent.EventId);
			this._writer.WriteAttributeString("session", ""+requestEvent.SessionId);
			this._writer.WriteAttributeString("method", requestEvent.Method);
			this._writer.WriteAttributeString("url", requestEvent.RawUrl);
			
			this._writer.WriteStartElement("headers");			
			NameValueCollection headers = requestEvent.Headers;
			foreach(string key in headers)
			{
				this._writer.WriteStartElement("header");
				this._writer.WriteAttributeString("name", key);
				this._writer.WriteAttributeString("value", headers[key]);
				this._writer.WriteEndElement();
			}
			this._writer.WriteEndElement();
			
			if (requestEvent.Base64EncodedPayload != null)
			{
				_writer.WriteElementString("payload", requestEvent.Base64EncodedPayload);
			}
			
			this._writer.WriteEndElement();
			this._writer.WriteWhitespace(Environment.NewLine);
		}

		public void Dispose()
		{
			this._writer.Flush();
			this._writer.Close();
			this._writer = null;
		}
	}
}