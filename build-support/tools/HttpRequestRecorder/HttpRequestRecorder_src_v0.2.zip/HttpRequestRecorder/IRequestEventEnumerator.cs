using System.Collections;

namespace HttpRequestRecorder
{
	public interface IRequestEventEnumerator : IEnumerator
	{
		new RequestEvent Current { get; }
	}
}