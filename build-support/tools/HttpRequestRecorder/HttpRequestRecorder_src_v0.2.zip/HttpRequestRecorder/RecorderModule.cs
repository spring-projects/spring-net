using System;
using System.Web;

namespace HttpRequestRecorder
{
	/// <summary>
	/// Summary description for RecorderModule.
	/// </summary>
	public class RecorderModule : IHttpModule
	{		
		private static volatile bool _isEnabled = false;

		public static bool IsEnabled
		{
			set
			{
				if (_isEnabled && !value)
				{
					Recorder.Flush();
				}
				_isEnabled = value;
			}
		}

		public void Init(HttpApplication context)
		{
			Recorder.EnsureRecorderInitialized(context);
			
			context.BeginRequest += new EventHandler(context_BeginRequest);
		}

		public void Dispose()
		{			
		}

		private void context_BeginRequest(object sender, EventArgs e)
		{
			if (!_isEnabled) return;

			HttpApplication application = (HttpApplication) sender;
			HttpRequest request = application.Context.Request;
			
			string sessionId;
			HttpCookie sessionCookie = request.Cookies["ASP.NET_SessionId"];
			if (sessionCookie == null)
			{
				sessionId = SessionId.Create();
				sessionCookie = new HttpCookie("ASP.NET_SessionId", sessionId);
				sessionCookie.Path = "/";
				application.Context.Request.Cookies.Add( sessionCookie );				
				application.Context.Response.Cookies.Add( sessionCookie );
			}
			else
			{
				sessionId = sessionCookie.Value;
			}
			
			Recorder.RecordRequestEvent(sessionId, request);
		}
	}
}
