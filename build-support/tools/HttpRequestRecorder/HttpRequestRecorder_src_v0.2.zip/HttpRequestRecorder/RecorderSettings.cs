namespace HttpRequestRecorder
{
	public class RecorderSettings
	{
		public readonly int BufferSize;
		public readonly string OutputPath;
		
		public RecorderSettings(int bufferSize, string outputPath)
		{
			this.BufferSize = bufferSize;
			this.OutputPath = outputPath;
		}		
	}
}